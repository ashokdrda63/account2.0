 // try {
    //   const response = await axios.post(
    //     "http://localhost:8000/insert_outward_voucher",
    //     temp
    //   );
    //   console.log("res", response.data);
    // } catch (error) {
    //   console.error("Error:", error);
    // }

    // try {
    //   const response = await axios.post(
    //     "http://localhost:8000/insert_inword_voucher",
    //     vchInEntSync
    //   );
    //   console.log("res", response.data);
    // } catch (error) {
    //   console.error("Error:", error);
    // }